function getSelectedLayersIdx (){ 
    var selectedLayers = new Array; 
    var ref = new ActionReference(); 
    ref.putEnumerated( charIDToTypeID("Dcmn"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt") ); 
    var desc = executeActionGet(ref); 
    if( desc.hasKey( stringIDToTypeID( 'targetLayers' ) ) ){ 
        desc = desc.getList( stringIDToTypeID( 'targetLayers' )); 
        var c = desc.count 
        var selectedLayers = new Array(); 
        for(var i=0;i<c;i++){ 
            try{ 
                activeDocument.backgroundLayer; 
                selectedLayers.push(  desc.getReference( i ).getIndex() ); 
            }catch(e){ 
                selectedLayers.push(  desc.getReference( i ).getIndex()+1 ); 
            } 
        } 
    }else{ 
        var ref = new ActionReference(); 
        ref.putProperty( charIDToTypeID("Prpr") , charIDToTypeID( "ItmI" )); 
        ref.putEnumerated( charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt") ); 
        try {
            activeDocument.backgroundLayer; 
            selectedLayers.push( executeActionGet(ref).getInteger(charIDToTypeID( "ItmI" ))-1); 
        } catch(e) {
            selectedLayers.push( executeActionGet(ref).getInteger(charIDToTypeID( "ItmI" ))); 
        } 
        var vis = app.activeDocument.activeLayer.visible;
        if(vis == true) app.activeDocument.activeLayer.visible = false;
        var desc9 = new ActionDescriptor();
        var list9 = new ActionList();
        var ref9 = new ActionReference();
        ref9.putEnumerated( charIDToTypeID('Lyr '), charIDToTypeID('Ordn'), charIDToTypeID('Trgt') );
        list9.putReference( ref9 );
        desc9.putList( charIDToTypeID('null'), list9 );
        executeAction( charIDToTypeID('Shw '), desc9, DialogModes.NO );
        if(app.activeDocument.activeLayer.visible == false) selectedLayers.shift();
        app.activeDocument.activeLayer.visible = vis;
    } 
    return selectedLayers; 
}

function zeroPad (n, s) { 
    n = n.toString(); 
    while (n.length < s) n = '0' + n; 
    return n; 
}

function forceCreateHistoySnapshot(name) {
    try{// remove the existing state
     var desc = new ActionDescriptor();
        var ref = new ActionReference();
        ref.putName( charIDToTypeID('SnpS'), name );
    desc.putReference( charIDToTypeID('null'), ref );
    executeAction( charIDToTypeID('Dlt '), desc, DialogModes.NO );
}catch(e){}
    var desc = new ActionDescriptor();// create from current state
        var classRef = new ActionReference();
        classRef.putClass( charIDToTypeID( "SnpS" ) );
    desc.putReference( charIDToTypeID( "null" ), classRef );
        var histRef = new ActionReference();
        histRef.putProperty( charIDToTypeID( "HstS" ), charIDToTypeID( "CrnH" ) );
    desc.putReference( charIDToTypeID( "From" ), histRef );
    desc.putString( charIDToTypeID( "Nm  " ), name );
    desc.putEnumerated( charIDToTypeID( "Usng" ), charIDToTypeID( "HstS" ), charIDToTypeID( "FllD" ) );
    desc.putBoolean( stringIDToTypeID( "replaceExisting" ), true );
executeAction( charIDToTypeID( "Mk  " ), desc, DialogModes.NO );
}

function getLayerNameByIndex( idx ) { 
    var ref = new ActionReference(); 
    ref.putProperty( charIDToTypeID('Prpr') , charIDToTypeID( 'Nm  ' )); 
    ref.putIndex( charIDToTypeID( 'Lyr ' ), idx );
    return executeActionGet(ref).getString(charIDToTypeID( 'Nm  ' ));; 
}

function putLayerNameByIndex ( idx, name ) {
    if( idx == 0 ) return;
    var desc = new ActionDescriptor();
    var ref = new ActionReference();
    ref.putIndex( charIDToTypeID( 'Lyr ' ), idx );
    desc.putReference( charIDToTypeID('null'), ref );
    var nameDesc = new ActionDescriptor();
    nameDesc.putString( charIDToTypeID('Nm  '), name );
    desc.putObject( charIDToTypeID('T   '), charIDToTypeID('Lyr '), nameDesc );
    executeAction( charIDToTypeID( 'slct' ), desc, DialogModes.NO ); 
    executeAction( charIDToTypeID('setd'), desc, DialogModes.NO );
}

function addToSelection( idx ) {
    var idslct = charIDToTypeID( "slct" );
    var desc26 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
    var ref17 = new ActionReference();
    var idLyr = charIDToTypeID( "Lyr " );
    ref17.putIndex( charIDToTypeID( 'Lyr ' ), idx );
    desc26.putReference( idnull, ref17 );
    var idselectionModifier = stringIDToTypeID( "selectionModifier" );
    var idselectionModifierType = stringIDToTypeID( "selectionModifierType" );
    var idaddToSelection = stringIDToTypeID( "addToSelection" );
    desc26.putEnumerated( idselectionModifier, idselectionModifierType, idaddToSelection );
    var idMkVs = charIDToTypeID( "MkVs" );
    desc26.putBoolean( idMkVs, false );
    executeAction( idslct, desc26, DialogModes.NO );
 }

function colorizeLayer(colorName) { // "Rd  ", "Orng", "Ylw ", "Grn ", "Bl  ", "Vlt ", "Gry ", "None"
    var idsetd = charIDToTypeID( "setd" );
    var desc40 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
    var ref29 = new ActionReference();
    var idLyr = charIDToTypeID( "Lyr " );      
    
    var idOrdn = charIDToTypeID( "Ordn" );
    var idTrgt = charIDToTypeID( "Trgt" );
    ref29.putEnumerated( idLyr, idOrdn, idTrgt );
    
    desc40.putReference( idnull, ref29 );
    var idT = charIDToTypeID( "T   " );
    var desc41 = new ActionDescriptor();
    var idClr = charIDToTypeID( "Clr " );
    var idClr = charIDToTypeID( "Clr " );
    var idVlt = charIDToTypeID( colorName );
    desc41.putEnumerated( idClr, idClr, idVlt );
    var idLyr = charIDToTypeID( "Lyr " );
    desc40.putObject( idT, idLyr, desc41 );
    executeAction( idsetd, desc40, DialogModes.NO );
}

function selectLayer(idx) {    
    var idslct = charIDToTypeID( "slct" );
    var desc72 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
    var ref52 = new ActionReference();
    var idLyr = charIDToTypeID( "Lyr " );
    ref52.putIndex( charIDToTypeID( 'Lyr ' ), idx );
    desc72.putReference( idnull, ref52 );
    var idMkVs = charIDToTypeID( "MkVs" );
    desc72.putBoolean( idMkVs, false );
    executeAction( idslct, desc72, DialogModes.NO );
}

function IsMacintoshOS() {
    if ( $.os.search(/macintosh/i) != -1 ) {
        return true;
    } else {
        return false;
    }
}

function IsWindowsOS() {
    if ( $.os.search(/windows/i) != -1 ) {
        return true;
    } else {
        return false;
    }
}

function getNamesFile() {
    if (IsMacintoshOS ())
    {
        var f = new File("~/Library/renamy.names");
        return f;
    } else {
        // C:\Users\andrey.GRUPOXANGO\AppData\Roaming\renamy.names
        var f = new File(Folder.userData + "/renamy.names");
        return f;
    }
}

function readNamesFile() {
    var names = new Array();
    var file = null;
    try {    
        file = getNamesFile();

        if (file.exists) {
            file.encoding="UTF-8";
            file.open ("r");
            while (true) {
                var s = file.readln();
                if (s.length == 0)
                    break;
                names.push(s);
            }
        }
    } catch(e) {
            alert("Failed to read names file: " + e, "Error");
    }

    if (file)
        file.close();
    return names;
}

function createTag(name, data) {
    var result = new XML("<" + name + "></" + name + ">");
    result.appendChild(data);
    return result;
}

function findSubstr(str, substr, startPos) {
    for (var i = startPos; i <= str.length - substr.length; ++i) {
        var found = true;
        for (var j = 0; j < substr.length; ++j) {
            if (str[i + j] != substr[j]) {
                found = false;
                break;
            }
        }
        if (found)
            return i;
    }
    return -1;
}

function replaceAll(str, from, to) {
    var i = findSubstr(str, from, 0);
    while (i != -1) {
        str = str.substr(0, i) + to + str.substr(i + from.length);
        i = findSubstr(str, from, i + to.length);
    }
    return str;
}

var layersName = "";
function renameImpl() { // uses layersName as a parameter
    var selectedLayers = getSelectedLayersIdx();

    var dog = layersName.search("%");
    var indexLength = 0;
    var asc = true;
    if (dog != -1 && dog != layersName.length && (layersName[dog + 1] == 'N' || layersName[dog + 1] == 'n')) {
        asc = (layersName[dog + 1] == 'N');
        for (var i = dog + 1; i < layersName.length; ++i) {
            if (asc) {
                if (layersName[i] != 'N')
                    break;
            }
            else {
                if (layersName[i] != 'n')
                    break;
            }

            ++indexLength;
        }
    }

    var outputIndex = asc ? selectedLayers.length + 1 : 0;

    for(var a in selectedLayers){
        var name = layersName;
        if (name.length == 0)
            continue;
        
        var replacePos = name.indexOf("->");
        var regexPos = name.indexOf("=>");
        if (replacePos != -1 && regexPos == -1) {
            var arr = name.split("->");
            if (arr.length == 2)
                name = replaceAll(getLayerNameByIndex(Number(selectedLayers[a])), arr[0], arr[1]);
        } else if (replacePos == -1 && regexPos != -1) {
            var arr = name.split("=>");
            if (arr.length == 2)
                name = getLayerNameByIndex(Number(selectedLayers[a])).replace(new RegExp(arr[0], "g"), arr[1]);
        }
        else {
            if (indexLength > 0) {
                var strIndex = (asc ? --outputIndex : ++outputIndex).toString(10);
                while (strIndex.length < indexLength)
                    strIndex = "0" + strIndex;
                 // Here lengh of strIndex could be greater than IndexLength if it was so from the beginning (too bug number), but don't truncate it
                 name = name.substr(0, dog) + strIndex + name.substr(dog + 1 + indexLength);
            }

            if (name[0] == '+')
                name = getLayerNameByIndex(Number(selectedLayers[a])) + name.substring(1);

            name = replaceAll(name, "*", getLayerNameByIndex(Number(selectedLayers[a])));
        }

        putLayerNameByIndex(Number(selectedLayers[a]), name);
    }

    for(var a in selectedLayers){
        addToSelection(Number(selectedLayers[a]));
    }
}


com_renamy = {

saveNewNamesFile: function() { // Accepts array of strings
    var file = null;
     try {
        file = getNamesFile();
        file.encoding="UTF-8";
        file.open("w");
        for (var i = 0; i < arguments.length; i++) {
            file.writeln(arguments[i]);
        }
    } catch(e) {
            alert("Failed to save names file: " + e, "Error");
    }

    if (file)
        file.close();
},

clearNamesFile: function() {
    var file = null;
     try {
        file = getNamesFile();
        file.encoding="UTF-8";
        file.open("w");
    } catch(e) {
            alert("Failed to clear names file: " + e, "Error");
    }

    if (file)
        file.close();
},

addName: function(name) { // Accepts string
    var file = null;
     try {
        file = getNamesFile();
        file.encoding="UTF-8";
        file.open("a");
        file.writeln(name);
    } catch(e) {
            alert("Failed to save names file: " + e, "Error");
    }

    if (file)
        file.close();
},

readNamesFileZZ: function() {
    try {    
        var names = readNamesFile();
        var result = new XML("<names />");
        for (var n in names) {
            result.appendChild(createTag("name", names[n]));
        }
        return result.toXMLString();
    } catch(e) {
            alert("Failed to read names file: " + e, "Error");
    }
    return "";
},

namesFileAsXml: function() {
    try {    
        var names = readNamesFile();
        var result = new XML("<names />");
        for (var n in names) {
            result.appendChild(createTag("name", names[n]));
        }
        return "<object><property id=\"names\"><string>" + result.toXMLString() + "</string></property></object>";
    } catch(e) {
            alert("Failed to read names file: " + e, "Error");
    }
    return "<object><property id=\"names\"><string></string></property></object>";
},

rename: function(layersNameParam) {
    if(!documents.length) return;
    layersName = layersNameParam;
    app.activeDocument.suspendHistory("Renamy Backup", "renameImpl()");    
},

colorize: function(colorName) { // "Rd  ", "Orng", "Ylw ", "Grn ", "Bl  ", "Vlt ", "Gry ", "None"
    if(!documents.length) return;
    var selectedLayers = getSelectedLayersIdx();

    for(var a in selectedLayers){
        selectLayer(Number(selectedLayers[a]));
        colorizeLayer(colorName);
    }

    for(var a in selectedLayers){    
        addToSelection(Number(selectedLayers[a]));
    }
},

group: function(groupName) {
    // =======================================================
    var idMk = charIDToTypeID( "Mk  " );
    var desc113 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
    var ref83 = new ActionReference();
    var idlayerSection = stringIDToTypeID( "layerSection" );
    ref83.putClass( idlayerSection );
    desc113.putReference( idnull, ref83 );
    var idFrom = charIDToTypeID( "From" );
    var ref84 = new ActionReference();
    var idLyr = charIDToTypeID( "Lyr " );
    var idOrdn = charIDToTypeID( "Ordn" );
    var idTrgt = charIDToTypeID( "Trgt" );
    ref84.putEnumerated( idLyr, idOrdn, idTrgt );
    desc113.putReference( idFrom, ref84 );
    executeAction( idMk, desc113, DialogModes.NO );

    // =======================================================
    var idsetd = charIDToTypeID( "setd" );
    var desc114 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
    var ref85 = new ActionReference();
    var idLyr = charIDToTypeID( "Lyr " );
    var idOrdn = charIDToTypeID( "Ordn" );
    var idTrgt = charIDToTypeID( "Trgt" );
    ref85.putEnumerated( idLyr, idOrdn, idTrgt );
    desc114.putReference( idnull, ref85 );
    var idT = charIDToTypeID( "T   " );
    var desc115 = new ActionDescriptor();
    var idNm = charIDToTypeID( "Nm  " );
    desc115.putString( idNm, groupName );
    var idLyr = charIDToTypeID( "Lyr " );
    desc114.putObject( idT, idLyr, desc115 );
    executeAction( idsetd, desc114, DialogModes.NO );
},

userData: function() {
    // MacOS - /Applications/Adobe Photoshop CS6/Adobe Photoshop CS6.app/Contents/MacOS/
    var dir = Folder.startup.fsName;
    if ($.os.toLowerCase().indexOf("win") == -1)
        dir += "/../../..";
    dir += "/Plug-ins/Panels/Renamy/";

    var userfile = null;
    var user = "";
    try {    
        userfile = new File(dir + "user.txt");
        userfile.encoding="UTF-8";
        userfile.open ("r");
        user = userfile.readln();
    } catch(e) {
            alert("Failed to read user file: " + e, "Error");
    }

    if (userfile)
        userfile.close();

    var signfile = null;
    var sign = "";
    try {    
        signfile = new File(dir + "sign.txt");
        signfile.encoding="UTF-8";
        signfile.open ("r");
        sign = signfile.readln();
    } catch(e) {
            alert("Failed to read sign file: " + e, "Error");
    }

    if (signfile)
        signfile.close();

    try {
        var result = new XML("<user />");
        result.appendChild(createTag("name", user));
        result.appendChild(createTag("sign", sign));

        return "<object><property id=\"user\"><string>" + result.toXMLString() + "</string></property></object>";
    } catch(e) {
            alert("Failed to read user file: " + e, "Error");
    }
    return "<object><property id=\"user\"><string></string></property></object>";
}

};

$._ext_PHXS={
    run : function() {
    
    	/**********  Replace below sample code with your own JSX code  **********/
        var appName;	    
	    appName = "Hello Photoshop";	    
        alert(appName);
        /************************************************************************/
        
        return appName;
    },
};

$._ext_Renamy={

    rename : function(name) {
	com_renamy.rename(name);
    },

    addName : function(name) {
	com_renamy.addName(name);
    },

    clearNamesFile : function() {
	com_renamy.clearNamesFile();
    },

    readNamesFileFF : function() {
	return com_renamy.readNamesFileZZ();
    },
    
    colorize : function(name) {
	com_renamy.colorize(name);
    },
    
};